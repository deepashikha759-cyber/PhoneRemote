package com.example.phoneremote

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        fun addText(value: String, size: Float = 18f) {
            layout.addView(TextView(this).apply { text = value; textSize = size })
        }
        fun addButton(label: String, action: () -> Unit) {
            layout.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }

        addText("PhoneRemote", 28f)
        addText("Role: ${BuildConfig.APP_ROLE}")
        addText("")
        if (BuildConfig.APP_ROLE == "CONTROLLER") {
            addText("Controller setup")
            addText("This starter build is ready for the next setup stage: secure internet pairing.")
            addText("No commands are sent yet. Pairing must be approved on the receiver phone.")
        } else {
            addText("Receiver setup")
            addText("This app does not hide itself or accept commands until you approve pairing.")
            addButton("Enable screen-lock permission") { requestAdminPermission() }
            addButton("Lock this phone now (local test)") { lockLocally() }
            addText("The local test works only after you enable the Android permission above.")
        }
        setContentView(layout)
    }

    private fun adminComponent() = ComponentName(this, LockAdminReceiver::class.java)

    private fun requestAdminPermission() {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Optional permission: lets PhoneRemote lock this phone when you choose.")
        }
        startActivity(intent)
    }

    private fun lockLocally() {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.isAdminActive(adminComponent())) {
            dpm.lockNow()
        } else {
            Toast.makeText(this, "Enable the permission first.", Toast.LENGTH_LONG).show()
        }
    }
}
