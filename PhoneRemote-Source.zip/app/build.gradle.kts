plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.phoneremote"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.phoneremote"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    flavorDimensions += "role"
    productFlavors {
        create("controller") {
            dimension = "role"
            applicationIdSuffix = ".controller"
            versionNameSuffix = "-controller"
            buildConfigField("String", "APP_ROLE", "\"CONTROLLER\"")
        }
        create("receiver") {
            dimension = "role"
            applicationIdSuffix = ".receiver"
            versionNameSuffix = "-receiver"
            buildConfigField("String", "APP_ROLE", "\"RECEIVER\"")
        }
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
